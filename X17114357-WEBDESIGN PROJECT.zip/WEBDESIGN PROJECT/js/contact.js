function phone() {
  alert("Thank you for contacting us.");
}
function email() {
  alert("Thank you for emailing us we will respond within 24 hours.");
}